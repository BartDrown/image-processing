export function getCurrentImage(){
    // Return here canvas/image to process



}